# SpawnerESP — standalone Fabric client mod

A small, client-only Fabric mod for Minecraft Java 26.1. It does not depend on Meteor Client and does not require a server-side mod.

## Features
- Tracks mob spawner block entities in chunks already loaded by the Minecraft client.
- Configured search bounds: up to 10,000 blocks on each of X, Y, and Z from the player.
- Draws a red wireframe-style outline through walls.
- Press `.` (period) to toggle the feature.

## Important range limitation
The 10,000-block setting is a maximum coordinate range, not a request to force-load terrain. A client can only inspect chunks that Minecraft has already loaded and sent to it. Unloaded chunks cannot be searched or revealed by this client-only mod. The implementation listens for client chunk load/unload events and inspects the spawner block entities in those chunks, instead of iterating through every block in a huge cube.

## Build
Requires Java 25 and Gradle 9.4.1 (or use the included GitHub Actions workflow).

```sh
gradle build --no-daemon
```

The JAR is created in `build/libs/`.

## Implementation note
This project is an independent implementation. It does not bundle or reference Meteor Client classes. Its rendering structure follows the public Fabric 26.1 rendering API documentation.
