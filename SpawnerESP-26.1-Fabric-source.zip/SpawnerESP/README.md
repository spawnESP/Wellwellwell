# Spawner ESP — Minecraft Java 26.1 / Fabric

A minimal client-only Fabric mod project. Its only feature is a red wireframe outline around loaded Mob Spawner blocks within a limited area around the player. Press the `.` (PERIOD) key to toggle the ESP on or off; the status appears in the action bar.

## Target
- Minecraft Java 26.1
- Fabric Loader 0.18.4 or newer
- Fabric API 0.143.11+26.1
- Java 25 for building

## Build
Use a Java 25 JDK and Gradle 9.4 or newer, then run:

```bash
gradle build
```

The mod jar will be written to `build/libs/`.

## Notes
- Press `.` (PERIOD) to toggle Spawner ESP ON/OFF. It is enabled by default.
- Client-side only; the server does not need this mod installed.
- It can only highlight spawners that the client has already received as loaded world blocks. It cannot reveal blocks hidden in chunks the server has not sent.
- The render implementation is an initial source draft and has not been compiled or tested in this environment. Minecraft 26.1 uses a substantially changed rendering API; verify the build and rendering behavior in a Java 25 Fabric development environment before using it in a world/server.
