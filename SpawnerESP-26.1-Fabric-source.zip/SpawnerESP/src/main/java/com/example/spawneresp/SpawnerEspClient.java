package com.example.spawneresp;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.chat.Component;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import java.util.ArrayList;
import java.util.List;

/**
 * Client-only Mob Spawner outline. Scans a modest area periodically and draws
 * red wireframe boxes around loaded spawner blocks.
 */
public final class SpawnerEspClient implements ClientModInitializer {
    private static final int HORIZONTAL_RANGE = 24;
    private static final int VERTICAL_RANGE = 16;
    private static final int RESCAN_INTERVAL_TICKS = 20;

    private static List<BlockPos> spawners = List.of();
    private static int ticksUntilScan = 0;
    private static boolean enabled = true;
    private static KeyMapping toggleKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.spawneresp.toggle",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_PERIOD,
                "category.spawneresp"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.consumeClick()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.displayClientMessage(
                            Component.literal("Spawner ESP: " + (enabled ? "ON" : "OFF")),
                            true
                    );
                }
                if (!enabled) spawners = List.of();
                ticksUntilScan = 0;
            }

            if (!enabled) return;
            if (client.level == null || client.player == null) {
                spawners = List.of();
                ticksUntilScan = 0;
                return;
            }

            if (ticksUntilScan-- <= 0) {
                scanLoadedArea(client);
                ticksUntilScan = RESCAN_INTERVAL_TICKS;
            }
        });

        LevelRenderEvents.AFTER_TRANSLUCENT_TERRAIN.register(SpawnerEspClient::renderSpawners);
    }

    private static void scanLoadedArea(Minecraft client) {
        BlockPos center = client.player.blockPosition();
        List<BlockPos> found = new ArrayList<>();

        BlockPos min = center.offset(-HORIZONTAL_RANGE, -VERTICAL_RANGE, -HORIZONTAL_RANGE);
        BlockPos max = center.offset(HORIZONTAL_RANGE, VERTICAL_RANGE, HORIZONTAL_RANGE);

        for (BlockPos pos : BlockPos.betweenClosed(min, max)) {
            if (client.level.getBlockState(pos).is(Blocks.SPAWNER)) {
                found.add(pos.immutable());
            }
        }
        spawners = List.copyOf(found);
    }

    private static void renderSpawners(net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext context) {
        Minecraft client = Minecraft.getInstance();
        if (!enabled || client.level == null || client.player == null || spawners.isEmpty()) {
            return;
        }

        Vec3 camera = client.gameRenderer.getMainCamera().position();
        PoseStack poseStack = context.poseStack();
        poseStack.pushPose();
        poseStack.translate(-camera.x, -camera.y, -camera.z);

        VertexConsumer lines = context.bufferSource().getBuffer(RenderType.lines());
        for (BlockPos pos : spawners) {
            double distanceSqr = client.player.distanceToSqr(
                    pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
            if (distanceSqr > (HORIZONTAL_RANGE * HORIZONTAL_RANGE * 3.0)) {
                continue;
            }

            AABB box = new AABB(pos).inflate(0.002);
            LevelRenderer.renderLineBox(poseStack, lines, box, 1.0F, 0.0F, 0.0F, 1.0F);
        }

        poseStack.popPose();
        // The renderer owns the shared buffer source and flushes it after this event.
    }
}
