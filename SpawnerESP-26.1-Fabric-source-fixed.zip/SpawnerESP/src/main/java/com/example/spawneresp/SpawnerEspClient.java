package com.example.spawneresp;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexFormat;

import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.glfw.GLFW;

import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.renderer.MappableRingBuffer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;

public final class SpawnerEspClient implements ClientModInitializer {
    private static final int HORIZONTAL_RANGE = 24;
    private static final int VERTICAL_RANGE = 16;
    private static final int RESCAN_INTERVAL_TICKS = 20;
    private static final double MAX_RENDER_DISTANCE_SQUARED = 32.0 * 32.0;
    private static final float EDGE_HALF_WIDTH = 0.018f;

    /*
     * DEBUG_FILLED_SNIPPET uses position+color vertices. Removing the depth
     * state makes the outline visible through terrain and other blocks.
     */
    private static final RenderPipeline THROUGH_WALLS_PIPELINE =
            RenderPipelines.register(
                    RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
                            .withLocation(Identifier.fromNamespaceAndPath(
                                    "spawneresp", "pipeline/spawner_outline"))
                            .withDepthStencilState(Optional.empty())
                            .build()
            );

    private static final ByteBufferBuilder ALLOCATOR =
            new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
    private static final Vector4f COLOR_MODULATOR = new Vector4f(1f, 1f, 1f, 1f);
    private static final Vector3f MODEL_OFFSET = new Vector3f();
    private static final org.joml.Matrix4f TEXTURE_MATRIX = new org.joml.Matrix4f();

    private static List<BlockPos> spawners = List.of();
    private static int ticksUntilScan = 0;
    private static boolean enabled = true;

    private static BufferBuilder buffer;
    private static MappableRingBuffer vertexBuffer;

    private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(
            Identifier.fromNamespaceAndPath("spawneresp", "main")
    );

    private static final KeyMapping TOGGLE_KEY = KeyMappingHelper.registerKeyMapping(
            new KeyMapping(
                    "key.spawneresp.toggle",
                    com.mojang.blaze3d.platform.InputConstants.Type.KEYSYM,
                    GLFW.GLFW_KEY_PERIOD,
                    CATEGORY
            )
    );

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (TOGGLE_KEY.consumeClick()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendSystemMessage(Component.literal(
                            "Spawner ESP: " + (enabled ? "ON" : "OFF")
                    ));
                }
                if (!enabled) {
                    spawners = List.of();
                }
                ticksUntilScan = 0;
            }

            if (!enabled || client.level == null || client.player == null) {
                spawners = List.of();
                ticksUntilScan = 0;
                return;
            }

            if (ticksUntilScan-- <= 0) {
                scanLoadedArea(client);
                ticksUntilScan = RESCAN_INTERVAL_TICKS;
            }
        });

        LevelRenderEvents.AFTER_TRANSLUCENT_TERRAIN.register(this::renderSpawners);
    }

    private static void scanLoadedArea(Minecraft client) {
        BlockPos center = client.player.blockPosition();
        BlockPos min = center.offset(
                -HORIZONTAL_RANGE, -VERTICAL_RANGE, -HORIZONTAL_RANGE);
        BlockPos max = center.offset(
                HORIZONTAL_RANGE, VERTICAL_RANGE, HORIZONTAL_RANGE);

        List<BlockPos> found = new ArrayList<>();
        for (BlockPos pos : BlockPos.betweenClosed(min, max)) {
            if (client.level.getBlockState(pos).is(Blocks.SPAWNER)) {
                found.add(pos.immutable());
            }
        }
        spawners = List.copyOf(found);
    }

    private void renderSpawners(LevelRenderContext context) {
        if (!enabled || spawners.isEmpty()) {
            return;
        }

        Minecraft client = Minecraft.getInstance();
        if (client.level == null || client.player == null) {
            return;
        }

        PoseStack poseStack = context.poseStack();
        Vec3 camera = context.levelState().cameraRenderState.pos;

        poseStack.pushPose();
        poseStack.translate(-camera.x, -camera.y, -camera.z);

        buffer = new BufferBuilder(
                ALLOCATOR,
                THROUGH_WALLS_PIPELINE.getVertexFormatMode(),
                THROUGH_WALLS_PIPELINE.getVertexFormat()
        );

        Matrix4fc matrix = poseStack.last().pose();
        for (BlockPos pos : spawners) {
            double dx = pos.getX() + 0.5 - camera.x;
            double dy = pos.getY() + 0.5 - camera.y;
            double dz = pos.getZ() + 0.5 - camera.z;
            if (dx * dx + dy * dy + dz * dz > MAX_RENDER_DISTANCE_SQUARED) {
                continue;
            }
            addWireframe(matrix, buffer,
                    pos.getX(), pos.getY(), pos.getZ(),
                    1.0f, 1.0f, 1.0f);
        }

        poseStack.popPose();

        MeshData builtBuffer = buffer.buildOrThrow();
        buffer = null;

        MeshData.DrawState drawParameters = builtBuffer.drawState();
        VertexFormat format = drawParameters.format();
        GpuBuffer vertices = upload(drawParameters, format, builtBuffer);
        draw(client, THROUGH_WALLS_PIPELINE, builtBuffer, drawParameters, vertices, format);

        vertexBuffer.rotate();
    }

    /*
     * Build a wireframe from twelve very thin rectangular bars. This uses
     * the 26.1 debug-filled pipeline, avoiding the removed RenderType.lines()
     * and LevelRenderer.renderLineBox() APIs.
     */
    private static void addWireframe(
            Matrix4fc matrix, BufferBuilder out,
            float x, float y, float z,
            float sizeX, float sizeY, float sizeZ
    ) {
        float t = EDGE_HALF_WIDTH;
        float x1 = x + sizeX;
        float y1 = y + sizeY;
        float z1 = z + sizeZ;

        // Four vertical edges.
        addFilledBox(matrix, out, x - t, y, z - t, x + t, y1, z + t);
        addFilledBox(matrix, out, x1 - t, y, z - t, x1 + t, y1, z + t);
        addFilledBox(matrix, out, x - t, y, z1 - t, x + t, y1, z1 + t);
        addFilledBox(matrix, out, x1 - t, y, z1 - t, x1 + t, y1, z1 + t);

        // Four edges along X.
        addFilledBox(matrix, out, x, y - t, z - t, x1, y + t, z + t);
        addFilledBox(matrix, out, x, y1 - t, z - t, x1, y1 + t, z + t);
        addFilledBox(matrix, out, x, y - t, z1 - t, x1, y + t, z1 + t);
        addFilledBox(matrix, out, x, y1 - t, z1 - t, x1, y1 + t, z1 + t);

        // Four edges along Z.
        addFilledBox(matrix, out, x - t, y - t, z, x + t, y + t, z1);
        addFilledBox(matrix, out, x1 - t, y - t, z, x1 + t, y + t, z1);
        addFilledBox(matrix, out, x - t, y1 - t, z, x + t, y1 + t, z1);
        addFilledBox(matrix, out, x1 - t, y1 - t, z, x1 + t, y1 + t, z1);
    }

    private static void addFilledBox(
            Matrix4fc matrix, BufferBuilder out,
            float minX, float minY, float minZ,
            float maxX, float maxY, float maxZ
    ) {
        final float r = 1.0f, g = 0.0f, b = 0.0f, a = 1.0f;

        // Front and back.
        vertex(out, matrix, minX, minY, maxZ, r, g, b, a);
        vertex(out, matrix, maxX, minY, maxZ, r, g, b, a);
        vertex(out, matrix, maxX, maxY, maxZ, r, g, b, a);
        vertex(out, matrix, minX, maxY, maxZ, r, g, b, a);

        vertex(out, matrix, maxX, minY, minZ, r, g, b, a);
        vertex(out, matrix, minX, minY, minZ, r, g, b, a);
        vertex(out, matrix, minX, maxY, minZ, r, g, b, a);
        vertex(out, matrix, maxX, maxY, minZ, r, g, b, a);

        // Left and right.
        vertex(out, matrix, minX, minY, minZ, r, g, b, a);
        vertex(out, matrix, minX, minY, maxZ, r, g, b, a);
        vertex(out, matrix, minX, maxY, maxZ, r, g, b, a);
        vertex(out, matrix, minX, maxY, minZ, r, g, b, a);

        vertex(out, matrix, maxX, minY, maxZ, r, g, b, a);
        vertex(out, matrix, maxX, minY, minZ, r, g, b, a);
        vertex(out, matrix, maxX, maxY, minZ, r, g, b, a);
        vertex(out, matrix, maxX, maxY, maxZ, r, g, b, a);

        // Top and bottom.
        vertex(out, matrix, minX, maxY, maxZ, r, g, b, a);
        vertex(out, matrix, maxX, maxY, maxZ, r, g, b, a);
        vertex(out, matrix, maxX, maxY, minZ, r, g, b, a);
        vertex(out, matrix, minX, maxY, minZ, r, g, b, a);

        vertex(out, matrix, minX, minY, minZ, r, g, b, a);
        vertex(out, matrix, maxX, minY, minZ, r, g, b, a);
        vertex(out, matrix, maxX, minY, maxZ, r, g, b, a);
        vertex(out, matrix, minX, minY, maxZ, r, g, b, a);
    }

    private static void vertex(
            BufferBuilder out, Matrix4fc matrix,
            float x, float y, float z,
            float r, float g, float b, float a
    ) {
        out.addVertex(matrix, x, y, z).setColor(r, g, b, a);
    }

    private static GpuBuffer upload(
            MeshData.DrawState drawParameters,
            VertexFormat format,
            MeshData builtBuffer
    ) {
        int vertexBufferSize = drawParameters.vertexCount() * format.getVertexSize();
        if (vertexBuffer == null || vertexBuffer.size() < vertexBufferSize) {
            if (vertexBuffer != null) {
                vertexBuffer.close();
            }
            vertexBuffer = new MappableRingBuffer(
                    () -> "SpawnerESP vertex buffer",
                    GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE,
                    vertexBufferSize
            );
        }

        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
        try (GpuBuffer.MappedView mapped = encoder.mapBuffer(
                vertexBuffer.currentBuffer().slice(
                        0, builtBuffer.vertexBuffer().remaining()),
                false, true
        )) {
            MemoryUtil.memCopy(builtBuffer.vertexBuffer(), mapped.data());
        }
        return vertexBuffer.currentBuffer();
    }

    private static void draw(
            Minecraft client,
            RenderPipeline pipeline,
            MeshData builtBuffer,
            MeshData.DrawState drawParameters,
            GpuBuffer vertices,
            VertexFormat format
    ) {
        GpuBuffer indices;
        VertexFormat.IndexType indexType;

        if (pipeline.getVertexFormatMode() == VertexFormat.Mode.QUADS) {
            builtBuffer.sortQuads(
                    ALLOCATOR, RenderSystem.getProjectionType().vertexSorting());
            indices = pipeline.getVertexFormat().uploadImmediateIndexBuffer(
                    builtBuffer.indexBuffer());
            indexType = builtBuffer.drawState().indexType();
        } else {
            RenderSystem.AutoStorageIndexBuffer shapeIndexBuffer =
                    RenderSystem.getSequentialBuffer(pipeline.getVertexFormatMode());
            indices = shapeIndexBuffer.getBuffer(drawParameters.indexCount());
            indexType = shapeIndexBuffer.type();
        }

        GpuBufferSlice transforms = RenderSystem.getDynamicUniforms().writeTransform(
                RenderSystem.getModelViewMatrix(),
                COLOR_MODULATOR,
                MODEL_OFFSET,
                TEXTURE_MATRIX
        );

        try (RenderPass pass = RenderSystem.getDevice()
                .createCommandEncoder()
                .createRenderPass(
                        () -> "SpawnerESP outline",
                        client.getMainRenderTarget().getColorTextureView(),
                        OptionalInt.empty(),
                        client.getMainRenderTarget().getDepthTextureView(),
                        OptionalDouble.empty()
                )) {
            pass.setPipeline(pipeline);
            RenderSystem.bindDefaultUniforms(pass);
            pass.setUniform("DynamicTransforms", transforms);
            pass.setVertexBuffer(0, vertices);
            pass.setIndexBuffer(indices, indexType);
            pass.drawIndexed(0 / format.getVertexSize(), 0,
                    drawParameters.indexCount(), 1);
        }

        builtBuffer.close();
    }
}
