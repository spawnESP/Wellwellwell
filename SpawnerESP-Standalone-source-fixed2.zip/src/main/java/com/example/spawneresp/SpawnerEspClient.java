package com.example.spawneresp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.OptionalInt;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexFormat;

import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.glfw.GLFW;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.system.MemoryUtil;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MappableRingBuffer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.Vec3;

/**
 * Independent client-only implementation. No Meteor Client classes are used.
 * Tracks mob spawner block entities in loaded client chunks and draws red edge boxes.
 */
public final class SpawnerEspClient implements ClientModInitializer {
    // Search radius from the player on each axis. Only chunks already loaded by
    // Minecraft can be inspected by a client-side mod.
    private static final int RANGE_X = 10_000;
    private static final int RANGE_Y = 10_000;
    private static final int RANGE_Z = 10_000;
    private static final float EDGE_WIDTH = 0.025f;
    private static final float RED = 1.0f;
    private static final float GREEN = 0.035f;
    private static final float BLUE = 0.035f;
    private static final float ALPHA = 1.0f;

    private static final RenderPipeline THROUGH_WALLS = RenderPipelines.register(
        RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
            .withLocation(Identifier.fromNamespaceAndPath("spawneresp", "pipeline/spawner_edges"))
            .withDepthStencilState(Optional.empty())
            .build()
    );

    private static final ByteBufferBuilder ALLOCATOR = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
    private static final Vector4f COLOR_MODULATOR = new Vector4f(1f, 1f, 1f, 1f);
    private static final Vector3f MODEL_OFFSET = new Vector3f();
    private static final org.joml.Matrix4f TEXTURE_MATRIX = new org.joml.Matrix4f();

    private static volatile List<BlockPos> spawners = List.of();
    private static final Map<Long, List<BlockPos>> SPAWNERS_BY_CHUNK = new HashMap<>();
    private static ClientLevel trackedLevel;
    private static boolean enabled = true;

    private KeyMapping toggleKey;
    private BufferBuilder buffer;
    private MappableRingBuffer vertexBuffer;

    private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(
        Identifier.fromNamespaceAndPath("spawneresp", "main")
    );

    @Override
    public void onInitializeClient() {
        toggleKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.spawneresp.toggle",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_PERIOD,
            CATEGORY
        ));

        // Record spawners only when Minecraft loads a chunk into the client.
        // This avoids iterating billions of block positions for a 10,000-block radius.
        ClientChunkEvents.CHUNK_LOAD.register((level, chunk) -> {
            if (level != Minecraft.getInstance().level) return;
            ensureTrackedLevel(level);
            rememberChunkSpawners(chunk);
        });

        ClientChunkEvents.CHUNK_UNLOAD.register((level, chunk) -> {
            if (level != trackedLevel) return;
            SPAWNERS_BY_CHUNK.remove(chunk.getPos().pack());
            refreshVisibleSpawners(level);
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.consumeClick()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                        "SpawnerESP: " + (enabled ? "ON" : "OFF")
                    ));
                }
            }

            if (client.level == null || client.player == null) {
                trackedLevel = null;
                SPAWNERS_BY_CHUNK.clear();
                spawners = List.of();
                return;
            }

            ensureTrackedLevel(client.level);
            refreshVisibleSpawners(client.level);
        });

        LevelRenderEvents.AFTER_TRANSLUCENT_TERRAIN.register(this::renderSpawners);
    }

    private static void ensureTrackedLevel(ClientLevel level) {
        if (trackedLevel != level) {
            trackedLevel = level;
            SPAWNERS_BY_CHUNK.clear();
            spawners = List.of();
        }
    }

    private static void rememberChunkSpawners(LevelChunk chunk) {
        List<BlockPos> found = new ArrayList<>();
        for (BlockEntity blockEntity : chunk.getBlockEntities().values()) {
            if (blockEntity instanceof SpawnerBlockEntity) {
                found.add(blockEntity.getBlockPos().immutable());
            }
        }
        SPAWNERS_BY_CHUNK.put(chunk.getPos().pack(), List.copyOf(found));
        if (trackedLevel != null) refreshVisibleSpawners(trackedLevel);
    }

    private static void refreshVisibleSpawners(ClientLevel level) {
        if (!enabled || Minecraft.getInstance().player == null) {
            spawners = List.of();
            return;
        }

        BlockPos center = Minecraft.getInstance().player.blockPosition();
        List<BlockPos> found = new ArrayList<>();
        for (List<BlockPos> chunkSpawners : SPAWNERS_BY_CHUNK.values()) {
            for (BlockPos pos : chunkSpawners) {
                if (Math.abs((long) pos.getX() - center.getX()) <= RANGE_X
                    && Math.abs((long) pos.getY() - center.getY()) <= RANGE_Y
                    && Math.abs((long) pos.getZ() - center.getZ()) <= RANGE_Z) {
                    found.add(pos);
                }
            }
        }
        spawners = List.copyOf(found);
    }

    private void renderSpawners(LevelRenderContext context) {
        if (!enabled || spawners.isEmpty()) return;

        Minecraft client = Minecraft.getInstance();
        if (client.level == null || client.player == null) return;

        PoseStack poseStack = context.poseStack();
        Vec3 camera = context.levelState().cameraRenderState.pos;
        poseStack.pushPose();
        poseStack.translate(-camera.x, -camera.y, -camera.z);

        if (buffer == null) {
            buffer = new BufferBuilder(ALLOCATOR, THROUGH_WALLS.getVertexFormatMode(), THROUGH_WALLS.getVertexFormat());
        }

        Matrix4fc matrix = poseStack.last().pose();
        for (BlockPos pos : spawners) {
            BlockPos playerPos = client.player.blockPosition();
            if (Math.abs((long) pos.getX() - playerPos.getX()) > RANGE_X
                || Math.abs((long) pos.getY() - playerPos.getY()) > RANGE_Y
                || Math.abs((long) pos.getZ() - playerPos.getZ()) > RANGE_Z) continue;
            addWireBox(matrix, buffer, pos.getX(), pos.getY(), pos.getZ());
        }

        poseStack.popPose();

        if (buffer != null) {
            MeshData mesh = buffer.buildOrThrow();
            MeshData.DrawState drawState = mesh.drawState();
            VertexFormat format = drawState.format();
            GpuBuffer vertices = upload(drawState, format, mesh);
            draw(client, mesh, drawState, vertices, format);
            vertexBuffer.rotate();
            buffer = null;
        }
    }

    /** Build a wireframe from twelve very thin red cuboids. */
    private static void addWireBox(Matrix4fc matrix, BufferBuilder out, int x, int y, int z) {
        float x0 = x, y0 = y, z0 = z;
        float x1 = x + 1f, y1 = y + 1f, z1 = z + 1f;
        float t = EDGE_WIDTH;

        // Four vertical edges.
        addFilledBox(matrix, out, x0, y0, z0, x0 + t, y1, z0 + t);
        addFilledBox(matrix, out, x1 - t, y0, z0, x1, y1, z0 + t);
        addFilledBox(matrix, out, x0, y0, z1 - t, x0 + t, y1, z1);
        addFilledBox(matrix, out, x1 - t, y0, z1 - t, x1, y1, z1);

        // Four edges along X (top and bottom, front and back).
        addFilledBox(matrix, out, x0, y0, z0, x1, y0 + t, z0 + t);
        addFilledBox(matrix, out, x0, y1 - t, z0, x1, y1, z0 + t);
        addFilledBox(matrix, out, x0, y0, z1 - t, x1, y0 + t, z1);
        addFilledBox(matrix, out, x0, y1 - t, z1 - t, x1, y1, z1);

        // Four edges along Z (top and bottom, left and right).
        addFilledBox(matrix, out, x0, y0, z0, x0 + t, y0 + t, z1);
        addFilledBox(matrix, out, x1 - t, y0, z0, x1, y0 + t, z1);
        addFilledBox(matrix, out, x0, y1 - t, z0, x0 + t, y1, z1);
        addFilledBox(matrix, out, x1 - t, y1 - t, z0, x1, y1, z1);
    }

    private static void addFilledBox(Matrix4fc m, BufferBuilder b,
                                     float minX, float minY, float minZ,
                                     float maxX, float maxY, float maxZ) {
        // Front
        vertex(b, m, minX, minY, maxZ); vertex(b, m, maxX, minY, maxZ);
        vertex(b, m, maxX, maxY, maxZ); vertex(b, m, minX, maxY, maxZ);
        // Back
        vertex(b, m, maxX, minY, minZ); vertex(b, m, minX, minY, minZ);
        vertex(b, m, minX, maxY, minZ); vertex(b, m, maxX, maxY, minZ);
        // Left
        vertex(b, m, minX, minY, minZ); vertex(b, m, minX, minY, maxZ);
        vertex(b, m, minX, maxY, maxZ); vertex(b, m, minX, maxY, minZ);
        // Right
        vertex(b, m, maxX, minY, maxZ); vertex(b, m, maxX, minY, minZ);
        vertex(b, m, maxX, maxY, minZ); vertex(b, m, maxX, maxY, maxZ);
        // Top
        vertex(b, m, minX, maxY, maxZ); vertex(b, m, maxX, maxY, maxZ);
        vertex(b, m, maxX, maxY, minZ); vertex(b, m, minX, maxY, minZ);
        // Bottom
        vertex(b, m, minX, minY, minZ); vertex(b, m, maxX, minY, minZ);
        vertex(b, m, maxX, minY, maxZ); vertex(b, m, minX, minY, maxZ);
    }

    private static void vertex(BufferBuilder b, Matrix4fc m, float x, float y, float z) {
        b.addVertex(m, x, y, z).setColor(RED, GREEN, BLUE, ALPHA);
    }

    private GpuBuffer upload(MeshData.DrawState drawState, VertexFormat format, MeshData mesh) {
        int size = drawState.vertexCount() * format.getVertexSize();
        if (vertexBuffer == null || vertexBuffer.size() < size) {
            if (vertexBuffer != null) vertexBuffer.close();
            vertexBuffer = new MappableRingBuffer(
                () -> "SpawnerESP vertex buffer",
                GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE,
                size
            );
        }

        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
        try (GpuBuffer.MappedView mapped = encoder.mapBuffer(
            vertexBuffer.currentBuffer().slice(0, mesh.vertexBuffer().remaining()), false, true
        )) {
            MemoryUtil.memCopy(mesh.vertexBuffer(), mapped.data());
        }
        return vertexBuffer.currentBuffer();
    }

    private static void draw(Minecraft client, MeshData mesh, MeshData.DrawState drawState,
                             GpuBuffer vertices, VertexFormat format) {
        GpuBuffer indices;
        VertexFormat.IndexType indexType;
        if (THROUGH_WALLS.getVertexFormatMode() == VertexFormat.Mode.QUADS) {
            mesh.sortQuads(ALLOCATOR, RenderSystem.getProjectionType().vertexSorting());
            indices = THROUGH_WALLS.getVertexFormat().uploadImmediateIndexBuffer(mesh.indexBuffer());
            indexType = mesh.drawState().indexType();
        } else {
            RenderSystem.AutoStorageIndexBuffer shape = RenderSystem.getSequentialBuffer(THROUGH_WALLS.getVertexFormatMode());
            indices = shape.getBuffer(drawState.indexCount());
            indexType = shape.type();
        }

        var dynamicTransforms = RenderSystem.getDynamicUniforms().writeTransform(
            RenderSystem.getModelViewMatrix(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX
        );

        try (RenderPass pass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(
            () -> "SpawnerESP through-wall outline",
            client.getMainRenderTarget().getColorTextureView(), OptionalInt.empty(),
            client.getMainRenderTarget().getDepthTextureView(), OptionalDouble.empty()
        )) {
            pass.setPipeline(THROUGH_WALLS);
            RenderSystem.bindDefaultUniforms(pass);
            pass.setUniform("DynamicTransforms", dynamicTransforms);
            pass.setVertexBuffer(0, vertices);
            pass.setIndexBuffer(indices, indexType);
            pass.drawIndexed(0, 0, drawState.indexCount(), 1);
        }
        mesh.close();
    }
}
